<?php 
get_header();
?>
<body <?php body_class(); ?>>
   
  <div class="container">
      <div class="row">
          <div class="col-md-12"> 
          <h1> 
          <h1 class="text-center">
         <?php 
          _e("<br>The content is not available<br> what you were looking!","alpha");
          ?>
       </h1>
          
          </h1>
          
          </div>
      </div>
      <div class="row button-404"> 
      
      <a href="<?php echo site_url();?>">Back to home page</a>
      </div>
  </div>
    
</body>



